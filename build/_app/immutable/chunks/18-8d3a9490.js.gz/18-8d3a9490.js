import{default as t}from"../components/pages/web-projects/satsukiina/images/_page.svelte-a4d7f5a8.js";export{t as component};
