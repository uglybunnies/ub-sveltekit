import{default as t}from"../components/error.svelte-6e2cd0cf.js";export{t as component};
