import{default as t}from"../components/pages/web-projects/_page.svelte-59dcbfd6.js";export{t as component};
