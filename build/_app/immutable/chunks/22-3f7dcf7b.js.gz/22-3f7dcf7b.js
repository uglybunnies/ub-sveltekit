import{default as t}from"../components/pages/web-projects/smcta/images/_page.svelte-fa7f52f5.js";export{t as component};
