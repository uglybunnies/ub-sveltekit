import{default as t}from"../components/pages/web-projects/platinum/_page.svelte-e5cbdaa9.js";export{t as component};
