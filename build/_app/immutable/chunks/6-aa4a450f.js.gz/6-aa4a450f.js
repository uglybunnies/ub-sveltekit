import{default as t}from"../components/pages/web-projects/adge/images/_page.svelte-94947015.js";export{t as component};
