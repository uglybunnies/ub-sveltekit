import{default as t}from"../components/pages/web-projects/serpentvenom/_page.svelte-448b1c71.js";export{t as component};
