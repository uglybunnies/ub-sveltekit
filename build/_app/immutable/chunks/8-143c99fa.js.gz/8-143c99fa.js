import{default as t}from"../components/pages/web-projects/rejuvenation-site/_page.svelte-c9d9fb14.js";export{t as component};
