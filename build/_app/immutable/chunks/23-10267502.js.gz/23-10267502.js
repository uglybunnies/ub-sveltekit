import{default as t}from"../components/pages/web-projects/urban-forest/_page.svelte-b43ff966.js";export{t as component};
