import{default as t}from"../components/pages/web-projects/urban-forest/images/_page.svelte-5cebfbb3.js";export{t as component};
