import{default as t}from"../components/pages/web-projects/platzner/_page.svelte-1ef186d4.js";export{t as component};
