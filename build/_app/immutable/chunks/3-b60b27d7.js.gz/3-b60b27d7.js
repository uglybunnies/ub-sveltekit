import{default as m}from"../components/pages/about/_page.svelte-a2ba2458.js";import"./index-20109a1f.js";export{m as component};
