import{default as r}from"../components/pages/web-projects/adge/_page.svelte-aa36a168.js";import"./index-20109a1f.js";import"./Captionbox-9ce45487.js";export{r as component};
