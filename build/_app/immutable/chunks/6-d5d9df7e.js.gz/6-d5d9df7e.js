import{default as t}from"../components/pages/web-projects/platinum/_page.svelte-f4743813.js";export{t as component};
