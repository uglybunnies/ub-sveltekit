import{default as t}from"../components/pages/web-projects/serpentvenom/images/_page.svelte-56c0ae65.js";export{t as component};
