import{default as t}from"../components/pages/web-projects/rejuvenation-site/images/_page.svelte-7bbf8576.js";export{t as component};
