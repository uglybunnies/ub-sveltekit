import{default as t}from"../components/pages/web-projects/smcta/_page.svelte-d04304ab.js";export{t as component};
