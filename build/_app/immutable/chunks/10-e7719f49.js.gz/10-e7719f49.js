import{default as t}from"../components/pages/web-projects/molekule/_page.svelte-28f50899.js";export{t as component};
