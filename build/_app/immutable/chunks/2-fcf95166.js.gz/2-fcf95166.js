import{default as t}from"../components/pages/_page.svelte-10f7a0ee.js";export{t as component};
