import{default as t}from"../components/pages/web-projects/corelight/_page.svelte-a0e6de52.js";export{t as component};
