import{default as m}from"../components/error.svelte-8f0800d6.js";import"./index-20109a1f.js";export{m as component};
