import{default as t}from"../components/pages/web-projects/adge/_page.svelte-24ac4245.js";export{t as component};
