import{default as t}from"../components/pages/web-projects/platzner/images/_page.svelte-19a26248.js";export{t as component};
