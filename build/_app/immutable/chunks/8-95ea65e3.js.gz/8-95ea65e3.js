import{default as r}from"../components/pages/web-projects/rejuvenation-site/_page.svelte-5e06aee1.js";import"./index-20109a1f.js";import"./Captionbox-9ce45487.js";export{r as component};
