import{default as t}from"../components/pages/web-projects/platzner/_page.svelte-1be7db8f.js";export{t as component};
