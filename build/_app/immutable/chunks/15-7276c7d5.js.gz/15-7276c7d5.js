import{default as t}from"../components/pages/web-projects/rejuvenation-site/_page.svelte-4f5cba0e.js";export{t as component};
