import{default as t}from"../components/pages/web-projects/urban-forest/_page.svelte-95bc66e5.js";export{t as component};
