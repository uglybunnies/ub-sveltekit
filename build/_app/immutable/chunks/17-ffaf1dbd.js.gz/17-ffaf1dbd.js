import{default as t}from"../components/pages/web-projects/satsukiina/_page.svelte-14819f3f.js";export{t as component};
