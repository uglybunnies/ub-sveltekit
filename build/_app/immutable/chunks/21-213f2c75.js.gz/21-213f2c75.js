import{default as t}from"../components/pages/web-projects/smcta/_page.svelte-396c93d4.js";export{t as component};
