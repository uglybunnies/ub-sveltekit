import{default as t}from"../components/pages/web-projects/autodesk/_page.svelte-1bfa8427.js";export{t as component};
