import{default as t}from"../components/pages/about/_page.svelte-62ef9f2a.js";export{t as component};
