import{default as t}from"../components/pages/web-projects/credit-karma/_page.svelte-67bf54b0.js";export{t as component};
