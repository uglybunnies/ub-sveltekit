import{default as r}from"../components/pages/web-projects/_page.svelte-a12a622d.js";import"./index-20109a1f.js";import"./Features-594b1068.js";export{r as component};
