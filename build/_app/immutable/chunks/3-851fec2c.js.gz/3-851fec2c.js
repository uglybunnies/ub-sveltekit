import{default as t}from"../components/pages/about/_page.svelte-ec3d2b99.js";export{t as component};
