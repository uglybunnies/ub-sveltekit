const s=!0,e=!1,r=!1,a=!1,t=Object.freeze(Object.defineProperty({__proto__:null,prerender:!0,csr:!1,ssr:!1,spa:!1},Symbol.toStringTag,{value:"Module"}));export{t as _,a,e as c,s as p,r as s};
