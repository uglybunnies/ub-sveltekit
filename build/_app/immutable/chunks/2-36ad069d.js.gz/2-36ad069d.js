import{default as t}from"../components/pages/_page.svelte-e1eae31a.js";export{t as component};
