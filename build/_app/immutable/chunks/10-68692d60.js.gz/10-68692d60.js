import{default as r}from"../components/pages/web-projects/serpentvenom/_page.svelte-d9e1d8fd.js";import"./index-20109a1f.js";import"./Captionbox-9ce45487.js";export{r as component};
