import{default as t}from"../components/pages/web-projects/serpentvenom/_page.svelte-dee02a01.js";export{t as component};
