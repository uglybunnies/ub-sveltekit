import{default as t}from"../components/pages/web-projects/satsukiina/_page.svelte-6f7c7ee2.js";export{t as component};
