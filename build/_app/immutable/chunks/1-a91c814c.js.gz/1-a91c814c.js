import{default as t}from"../components/error.svelte-66b3a569.js";export{t as component};
