import{default as t}from"../components/pages/web-projects/adge/_page.svelte-427504c8.js";export{t as component};
