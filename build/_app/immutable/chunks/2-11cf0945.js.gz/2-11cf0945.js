import{default as r}from"../components/pages/_page.svelte-9a8a8bd3.js";import"./index-20109a1f.js";import"./Features-594b1068.js";export{r as component};
