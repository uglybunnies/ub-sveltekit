import{_ as t}from"./_layout-674856a6.js";import{default as m}from"../components/pages/_layout.svelte-237a6e7a.js";import"./index-20109a1f.js";export{m as component,t as shared};
