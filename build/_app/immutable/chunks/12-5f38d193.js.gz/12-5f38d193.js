import{default as t}from"../components/pages/web-projects/platinum/images/_page.svelte-0eeee6d5.js";export{t as component};
