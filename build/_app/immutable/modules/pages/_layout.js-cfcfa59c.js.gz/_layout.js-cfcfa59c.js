import{c as a,p as e,a as p,s as c}from"../../chunks/_layout-674856a6.js";export{a as csr,e as prerender,p as spa,c as ssr};
